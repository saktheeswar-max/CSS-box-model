package com.edutrack.controller;

import com.edutrack.dto.AdminDashboardResponse;
import com.edutrack.dto.StudentDashboardResponse;
import com.edutrack.dto.TeacherDashboardResponse;
import com.edutrack.service.DashboardService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dashboard")
@CrossOrigin(origins = "*")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    // ✅ ADMIN DASHBOARD
    @GetMapping("/admin")
    public ResponseEntity<AdminDashboardResponse> getAdminDashboard() {
        return ResponseEntity.ok(dashboardService.getAdminDashboard());
    }

    // ✅ TEACHER DASHBOARD
    @GetMapping("/teacher/{teacherId}")
    public ResponseEntity<TeacherDashboardResponse> getTeacherDashboard(@PathVariable Long teacherId) {
        return ResponseEntity.ok(dashboardService.getTeacherDashboard(teacherId));
    }

    // ✅ STUDENT DASHBOARD
    @GetMapping("/student/{studentId}")
    public ResponseEntity<StudentDashboardResponse> getStudentDashboard(@PathVariable Long studentId) {
        return ResponseEntity.ok(dashboardService.getStudentDashboard(studentId));
    }
}
