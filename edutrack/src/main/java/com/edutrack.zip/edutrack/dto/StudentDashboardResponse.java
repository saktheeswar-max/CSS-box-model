package com.edutrack.dto;

public class StudentDashboardResponse {
    private Long timetableCount;
    private Long attendanceCount;
    private Long announcementsCount;

    public Long getTimetableCount() { return timetableCount; }
    public void setTimetableCount(Long timetableCount) { this.timetableCount = timetableCount; }

    public Long getAttendanceCount() { return attendanceCount; }
    public void setAttendanceCount(Long attendanceCount) { this.attendanceCount = attendanceCount; }

    public Long getAnnouncementsCount() { return announcementsCount; }
    public void setAnnouncementsCount(Long announcementsCount) { this.announcementsCount = announcementsCount; }
}
