package com.edutrack.dto;

public class TeacherDashboardResponse {
    private Long classesCount;
    private Long announcementsCount;

    public Long getClassesCount() { return classesCount; }
    public void setClassesCount(Long classesCount) { this.classesCount = classesCount; }

    public Long getAnnouncementsCount() { return announcementsCount; }
    public void setAnnouncementsCount(Long announcementsCount) { this.announcementsCount = announcementsCount; }
}
