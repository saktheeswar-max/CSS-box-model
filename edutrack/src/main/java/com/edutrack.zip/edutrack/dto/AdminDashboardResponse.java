package com.edutrack.dto;

public class AdminDashboardResponse {
    private Long totalStudents;
    private Long totalCourses;
    private Long totalEnrollments;
    private Long attendanceRecords;

    public Long getTotalStudents() { return totalStudents; }
    public void setTotalStudents(Long totalStudents) { this.totalStudents = totalStudents; }

    public Long getTotalCourses() { return totalCourses; }
    public void setTotalCourses(Long totalCourses) { this.totalCourses = totalCourses; }

    public Long getTotalEnrollments() { return totalEnrollments; }
    public void setTotalEnrollments(Long totalEnrollments) { this.totalEnrollments = totalEnrollments; }

    public Long getAttendanceRecords() { return attendanceRecords; }
    public void setAttendanceRecords(Long attendanceRecords) { this.attendanceRecords = attendanceRecords; }
}
