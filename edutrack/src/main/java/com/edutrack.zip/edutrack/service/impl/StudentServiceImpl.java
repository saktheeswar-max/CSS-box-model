package com.edutrack.service.impl;

import com.edutrack.entity.Student;
import com.edutrack.repository.StudentRepository;
import com.edutrack.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository repo;

    @Override
    public Student save(Student student) {
        return repo.save(student);
    }

    @Override
    public List<Student> findAll() {
        return repo.findAll();
    }

    @Override
    public void delete(Long id) {
        repo.deleteById(id);
    }
}
