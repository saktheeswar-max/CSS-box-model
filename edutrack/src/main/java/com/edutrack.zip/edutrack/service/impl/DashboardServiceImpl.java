package com.edutrack.service.impl;

import com.edutrack.dto.AdminDashboardResponse;
import com.edutrack.dto.StudentDashboardResponse;
import com.edutrack.dto.TeacherDashboardResponse;
import com.edutrack.repository.*;
import com.edutrack.service.DashboardService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DashboardServiceImpl implements DashboardService {

    @Autowired private StudentRepository studentRepository;
    @Autowired private CourseRepository courseRepository;
    @Autowired private EnrollmentRepository enrollmentRepository;
    @Autowired private AttendanceRepository attendanceRepository;
    @Autowired private TimetableRepository timetableRepository;
    @Autowired private AnnouncementRepository announcementRepository;

    @Override
    public AdminDashboardResponse getAdminDashboard() {
        AdminDashboardResponse res = new AdminDashboardResponse();
        res.setTotalStudents(studentRepository.count());
        res.setTotalCourses(courseRepository.count());
        res.setTotalEnrollments(enrollmentRepository.count());
        res.setAttendanceRecords(attendanceRepository.count());
        return res;
    }

    @Override
    public TeacherDashboardResponse getTeacherDashboard(Long teacherId) {
        TeacherDashboardResponse res = new TeacherDashboardResponse();
        res.setClassesCount(timetableRepository.countByTeacherId(teacherId));
        res.setAnnouncementsCount(announcementRepository.count());
        return res;
    }

    @Override
    public StudentDashboardResponse getStudentDashboard(Long studentId) {
        StudentDashboardResponse res = new StudentDashboardResponse();
        res.setTimetableCount(timetableRepository.countByStudentId(studentId));
        res.setAttendanceCount(attendanceRepository.countByStudentId(studentId));
        res.setAnnouncementsCount(announcementRepository.count());
        return res;
    }
}
